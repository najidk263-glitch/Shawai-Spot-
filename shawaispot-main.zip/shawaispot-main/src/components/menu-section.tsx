export type MenuItem = {
  name: string;
  description?: string;
  popular?: boolean;
};

export function MenuSection({
  title,
  emoji,
  items,
}: {
  title: string;
  emoji?: string;
  items: MenuItem[];
}) {
  return (
    <section className="mb-16">
      <div className="flex items-baseline gap-3 mb-6">
        {emoji && <span className="text-2xl">{emoji}</span>}
        <h3 className="font-serif text-2xl md:text-3xl text-foreground">{title}</h3>
        <span className="flex-1 h-px bg-gradient-to-r from-[var(--gold)]/50 to-transparent ml-2" />
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {items.map((item) => (
          <article key={item.name} className="menu-card p-5 relative">
            {item.popular && (
              <span className="absolute -top-2 right-4 text-[10px] uppercase tracking-[0.2em] bg-[var(--gradient-gold)] bg-clip-text text-transparent border border-[color-mix(in_oklab,var(--gold)_50%,transparent)] rounded-full px-2 py-0.5 bg-background">
                Popular
              </span>
            )}
            <h4 className="font-serif text-xl text-foreground">{item.name}</h4>
            {item.description && (
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
                {item.description}
              </p>
            )}
          </article>
        ))}
      </div>
    </section>
  );
}
