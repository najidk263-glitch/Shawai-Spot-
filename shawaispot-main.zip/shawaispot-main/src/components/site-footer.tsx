import { Link } from "@tanstack/react-router";
import { MapPin, Phone, Clock } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="border-t border-border mt-24 bg-card/40">
      <div className="mx-auto max-w-7xl px-6 py-14 grid gap-10 md:grid-cols-3">
        <div>
          <div className="flex flex-col leading-none mb-4">
            <span className="font-serif text-2xl tracking-[0.2em] text-gold">SHAWAI</span>
            <span className="font-serif text-xs tracking-[0.4em] text-muted-foreground">SPOT</span>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Pure Flavours — Arabian Kitchen. Authentic shawarma, alfahm, and madhooth
            crafted with traditional spices and care.
          </p>
        </div>

        <div className="space-y-3 text-sm">
          <h4 className="text-gold uppercase tracking-[0.25em] text-xs mb-4">Visit</h4>
          <p className="flex items-start gap-2 text-muted-foreground">
            <MapPin size={16} className="text-gold mt-0.5 shrink-0" />
            Main Road, Kannur, Kerala, India
          </p>
          <p className="flex items-center gap-2 text-muted-foreground">
            <Phone size={16} className="text-gold shrink-0" />
            +91 98765 43210
          </p>
          <p className="flex items-center gap-2 text-muted-foreground">
            <Clock size={16} className="text-gold shrink-0" />
            Daily · 11:00 AM – 11:30 PM
          </p>
        </div>

        <div className="space-y-3 text-sm">
          <h4 className="text-gold uppercase tracking-[0.25em] text-xs mb-4">Explore</h4>
          <div className="flex flex-col gap-2">
            <Link to="/menu" className="text-muted-foreground hover:text-gold transition">Full Menu</Link>
            <Link to="/beverages" className="text-muted-foreground hover:text-gold transition">Refreshments</Link>
            <Link to="/outlets" className="text-muted-foreground hover:text-gold transition">Our Outlets</Link>
            <Link to="/contact" className="text-muted-foreground hover:text-gold transition">Contact & Location</Link>
          </div>
        </div>
      </div>

      <div className="border-t border-border">
        <div className="mx-auto max-w-7xl px-6 py-5 text-xs text-muted-foreground flex flex-col md:flex-row items-center justify-between gap-2">
          <p>© {new Date().getFullYear()} Shawai Spot. All rights reserved.</p>
          <p className="italic">All prices are in INR. Pre-order items require advance booking.</p>
        </div>
      </div>
    </footer>
  );
}
