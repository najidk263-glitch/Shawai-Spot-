const WHATSAPP_NUMBER = "919876543210";
const MESSAGE = encodeURIComponent("Hi Shawai Spot, I'd like to place an order.");

export function WhatsappFab() {
  return (
    <a
      href={`https://wa.me/${WHATSAPP_NUMBER}?text=${MESSAGE}`}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Order on WhatsApp"
      className="fixed bottom-6 right-6 z-40 group flex items-center gap-3 rounded-full bg-[#25D366] text-white pl-4 pr-5 py-3 shadow-[0_10px_30px_-10px_rgba(37,211,102,0.6)] hover:scale-105 transition-transform"
    >
      <svg viewBox="0 0 32 32" className="w-6 h-6 fill-current" aria-hidden="true">
        <path d="M16.001 3C9.373 3 4 8.373 4 15c0 2.385.696 4.605 1.892 6.477L4 29l7.71-1.847A11.94 11.94 0 0 0 16 27c6.627 0 12-5.373 12-12S22.628 3 16.001 3Zm0 21.818c-1.78 0-3.428-.483-4.853-1.32l-.347-.207-4.572 1.097 1.118-4.444-.225-.36A9.78 9.78 0 0 1 6.182 15c0-5.42 4.4-9.818 9.819-9.818S25.819 9.58 25.819 15c0 5.42-4.4 9.818-9.818 9.818Zm5.622-7.36c-.308-.155-1.823-.9-2.106-1.003-.282-.103-.487-.155-.692.155s-.793 1.003-.972 1.21c-.18.207-.359.232-.667.077-.308-.154-1.302-.48-2.481-1.532-.917-.818-1.535-1.828-1.715-2.137-.18-.31-.019-.477.135-.63.139-.138.308-.36.462-.54.155-.18.206-.31.309-.516.103-.207.052-.387-.026-.541-.078-.155-.692-1.67-.948-2.288-.25-.6-.503-.518-.692-.527l-.59-.01c-.205 0-.539.077-.821.387-.282.31-1.077 1.052-1.077 2.566s1.103 2.978 1.257 3.184c.155.207 2.17 3.314 5.26 4.645.735.317 1.308.506 1.755.648.737.234 1.408.201 1.939.122.591-.088 1.823-.745 2.08-1.466.257-.722.257-1.34.18-1.466-.077-.13-.282-.207-.59-.362Z"/>
      </svg>
      <span className="hidden sm:inline text-sm font-medium tracking-wide">Order Now</span>
    </a>
  );
}
