import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-layout";
import { MapPin, Phone, Clock, Mail, MessageCircle } from "lucide-react";
import { OUTLETS, ORDER_MSG } from "@/data/outlets";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Outlets & Contact — Shawai Spot" },
      {
        name: "description",
        content:
          "Find your nearest Shawai Spot outlet. 5 locations serving authentic Arabian cuisine — addresses, hours and direct order numbers.",
      },
      { property: "og:title", content: "Our Outlets — Shawai Spot" },
      {
        property: "og:description",
        content: "5 Shawai Spot outlets — addresses, hours and direct order numbers.",
      },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <SiteLayout>
      <section className="py-16 px-6">
        <div className="max-w-5xl mx-auto text-center mb-14">
          <p className="section-eyebrow mb-4">Find Us</p>
          <h1 className="section-title">Our Outlets</h1>
          <div className="gold-divider" />
          <p className="text-muted-foreground max-w-xl mx-auto">
            Five locations, one taste of Arabia. Drop by, call ahead, or order on WhatsApp.
          </p>
        </div>

        <div className="max-w-6xl mx-auto space-y-8">
          {OUTLETS.map((o) => (
            <article
              key={o.name}
              className="menu-card overflow-hidden p-6 md:p-8"
            >
              <div className="flex flex-col">
                <h2 className="font-serif text-2xl md:text-3xl text-foreground">{o.name}</h2>
                <div className="h-px w-16 bg-[var(--gradient-gold)] my-4" />

                <div className="space-y-3 text-sm">
                  <p className="flex items-start gap-3 text-muted-foreground">
                    <MapPin size={16} className="text-gold mt-0.5 shrink-0" />
                    <span>{o.address}</span>
                  </p>
                  <p className="flex items-center gap-3 text-muted-foreground">
                    <Phone size={16} className="text-gold shrink-0" />
                    <a href={`tel:${o.phone.replace(/\s+/g, "")}`} className="hover:text-gold transition">
                      {o.phone}
                    </a>
                  </p>
                  <p className="flex items-center gap-3 text-muted-foreground">
                    <Clock size={16} className="text-gold shrink-0" />
                    {o.hours}
                  </p>
                </div>

                <div className="mt-6 flex flex-wrap gap-3">
                  <a
                    href={`tel:${o.phone.replace(/\s+/g, "")}`}
                    className="btn-call"
                  >
                    <Phone size={16} /> Call
                  </a>
                  <a
                    href={`https://wa.me/${o.whatsapp}?text=${ORDER_MSG}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-whatsapp"
                  >
                    <MessageCircle size={16} /> Order on WhatsApp
                  </a>
                </div>
              </div>
            </article>
          ))}
        </div>

        <div className="max-w-3xl mx-auto mt-16 text-center menu-card p-8">
          <p className="section-eyebrow mb-3">General Enquiries</p>
          <h3 className="font-serif text-2xl mb-2">Catering, Events & Press</h3>
          <p className="text-muted-foreground text-sm mb-4">
            For partnership, catering or media requests, get in touch with our head office.
          </p>
          <a
            href="mailto:hello@shawaispot.com"
            className="inline-flex items-center gap-2 text-gold hover:gap-3 transition-all"
          >
            <Mail size={16} /> hello@shawaispot.com
          </a>
        </div>

        <p className="text-center text-xs text-muted-foreground italic mt-10">
          All prices are in INR. Pre-order items require advance booking.
        </p>
      </section>
    </SiteLayout>
  );
}
