import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-layout";
import { ArrowRight, Flame, Leaf, Award } from "lucide-react";
import heroImg from "@/assets/hero-alfahm.jpg";
import shawarmaImg from "@/assets/gallery-shawarma.jpg";
import madhoothImg from "@/assets/gallery-madhooth.jpg";
import beveragesImg from "@/assets/gallery-beverages.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Shawai Spot — Pure Flavours · Arabian Kitchen" },
      {
        name: "description",
        content:
          "Shawai Spot serves authentic Arabian cuisine — shawarma, alfahm, madhooth and fresh beverages. Premium flavours, traditional recipes.",
      },
      { property: "og:title", content: "Shawai Spot — Arabian Kitchen" },
      {
        property: "og:description",
        content: "Authentic shawarma, alfahm, madhooth and fresh beverages. Pure Arabian flavours.",
      },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <SiteLayout>
      {/* HERO */}
      <section className="relative min-h-[92vh] flex items-center justify-center overflow-hidden -mt-20 pt-20">
        <div className="absolute inset-0">
          <img
            src={heroImg}
            alt="Signature alfahm grilled chicken on saffron rice with kuboos"
            width={1920}
            height={1080}
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/50 to-background" />
        </div>

        <div className="relative z-10 text-center px-6 max-w-3xl animate-fade-in">
          <p className="section-eyebrow mb-6">Arabian Kitchen</p>
          <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl tracking-tight text-foreground">
            SHAWAI <span className="gold-text-gradient">SPOT</span>
          </h1>
          <div className="gold-divider" />
          <p className="font-serif italic text-xl md:text-2xl text-muted-foreground">
            Pure Flavours — Arabian Kitchen
          </p>
          <p className="mt-6 max-w-xl mx-auto text-foreground/70 leading-relaxed">
            Slow-grilled meats, aromatic spices, and time-honoured recipes from the heart of Arabia,
            served in an atmosphere of quiet luxury.
          </p>

          <div className="mt-10 flex items-center justify-center gap-4 flex-wrap">
            <Link
              to="/menu"
              className="group inline-flex items-center gap-2 bg-[var(--gradient-gold)] text-primary-foreground px-7 py-3 rounded-full text-sm uppercase tracking-[0.25em] font-medium hover:shadow-[var(--shadow-gold)] transition-all"
            >
              View Menu
              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 border border-[color-mix(in_oklab,var(--gold)_50%,transparent)] text-foreground px-7 py-3 rounded-full text-sm uppercase tracking-[0.25em] hover:border-[var(--gold)] hover:text-gold transition-all"
            >
              Visit Us
            </Link>
          </div>
        </div>
      </section>

      {/* HIGHLIGHTS */}
      <section className="py-24 px-6">
        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-8">
          {[
            { icon: Flame, title: "Wood-Fire Grilled", text: "Alfahm and shawai grilled to perfection over open flames." },
            { icon: Leaf, title: "Authentic Spices", text: "Traditional Arabian blends — saffron, cardamom, sumac." },
            { icon: Award, title: "Premium Quality", text: "Hand-picked ingredients, prepared fresh every single day." },
          ].map(({ icon: Icon, title, text }) => (
            <div key={title} className="text-center px-4">
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-full border border-[color-mix(in_oklab,var(--gold)_40%,transparent)] mb-5">
                <Icon className="text-gold" size={22} />
              </div>
              <h3 className="font-serif text-2xl mb-2">{title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* SIGNATURE PREVIEW */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto text-center mb-14">
          <p className="section-eyebrow mb-4">Our Signatures</p>
          <h2 className="section-title">Crafted with Tradition</h2>
          <div className="gold-divider" />
        </div>

        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-6">
          {[
            { img: shawarmaImg, title: "Shawarma", desc: "Slow-roasted, hand-sliced." },
            { img: madhoothImg, title: "Madhooth", desc: "Aromatic spiced rice with tender meat." },
            { img: beveragesImg, title: "Refreshments", desc: "Mojitos, milkshakes & juices." },
          ].map((card) => (
            <article key={card.title} className="group relative overflow-hidden rounded-lg menu-card p-0">
              <div className="aspect-[4/5] overflow-hidden">
                <img
                  src={card.img}
                  alt={card.title}
                  loading="lazy"
                  width={1024}
                  height={1024}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <h3 className="font-serif text-2xl text-foreground">{card.title}</h3>
                <p className="text-sm text-muted-foreground mt-1">{card.desc}</p>
              </div>
            </article>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link
            to="/menu"
            className="inline-flex items-center gap-2 text-gold uppercase tracking-[0.25em] text-sm hover:gap-4 transition-all"
          >
            Explore Full Menu <ArrowRight size={16} />
          </Link>
        </div>
      </section>

      {/* QUOTE */}
      <section className="py-24 px-6 border-y border-border bg-card/30">
        <div className="max-w-3xl mx-auto text-center">
          <p className="font-serif italic text-3xl md:text-4xl text-foreground leading-snug">
            “Where Arabian tradition meets modern indulgence — every plate tells a story of fire, spice and soul.”
          </p>
          <div className="gold-divider" />
          <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">— The Shawai Spot Kitchen</p>
        </div>
      </section>
    </SiteLayout>
  );
}
