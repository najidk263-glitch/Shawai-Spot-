import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-layout";
import { MenuSection } from "@/components/menu-section";
import beveragesImg from "@/assets/gallery-beverages.jpg";

export const Route = createFileRoute("/beverages")({
  head: () => ({
    meta: [
      { title: "Refreshments — Shawai Spot · Milkshakes, Mojitos & Juices" },
      {
        name: "description",
        content:
          "Refreshing milkshakes, fresh juices, mojitos and lime drinks crafted to pair with Arabian cuisine at Shawai Spot.",
      },
      { property: "og:title", content: "Refreshments — Shawai Spot" },
      {
        property: "og:description",
        content: "Milkshakes, fresh juices, mojitos and lime drinks.",
      },
    ],
  }),
  component: BeveragesPage,
});

function BeveragesPage() {
  return (
    <SiteLayout>
      <section className="relative h-[40vh] -mt-20 pt-20 overflow-hidden">
        <img
          src={beveragesImg}
          alt="Fresh juices and mojitos"
          width={1920}
          height={800}
          className="absolute inset-0 w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/50 to-background" />
        <div className="relative z-10 h-full flex flex-col items-center justify-center text-center px-6">
          <p className="section-eyebrow mb-3">Drinks & More</p>
          <h1 className="section-title">Refreshments</h1>
          <div className="gold-divider" />
        </div>
      </section>

      <section className="py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <MenuSection
            title="Milkshakes"
            emoji="🥤"
            items={[
              { name: "Kannur Cocktail", description: "Our house signature blend.", popular: true },
              { name: "Chikoo" },
              { name: "Sharjah" },
              { name: "Avocado", popular: true },
              { name: "Strawberry" },
              { name: "Mango" },
              { name: "Cucumber" },
              { name: "Tender Coconut" },
            ]}
          />

          <MenuSection
            title="Fresh Juices"
            emoji="🍹"
            items={[
              { name: "Watermelon" },
              { name: "Pineapple" },
              { name: "Grape" },
              { name: "Orange" },
              { name: "Mosambi" },
            ]}
          />

          <MenuSection
            title="Mojitos"
            emoji="🍸"
            items={[
              { name: "Virgin Mojito", popular: true },
              { name: "Passion Fruit" },
              { name: "Blueberry" },
              { name: "Green Apple" },
              { name: "Blue Curacao" },
            ]}
          />

          <MenuSection
            title="Lime"
            emoji="🍋"
            items={[
              { name: "Fresh Lime" },
              { name: "Mint Lime" },
              { name: "Grape Lime" },
              { name: "Pineapple Lime" },
              { name: "Orange Lime" },
            ]}
          />
        </div>
      </section>
    </SiteLayout>
  );
}
