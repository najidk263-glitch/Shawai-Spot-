import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-layout";
import {
  MapPin,
  Phone,
  Clock,
  MessageCircle,
  User,
  Armchair,
  Car,
  Sparkles,
  CalendarDays,
} from "lucide-react";
import { OUTLETS, ORDER_MSG } from "@/data/outlets";

export const Route = createFileRoute("/outlets")({
  head: () => ({
    meta: [
      { title: "Our Outlets — Shawai Spot · 5 Locations" },
      {
        name: "description",
        content:
          "Full details for all 5 Shawai Spot outlets — Kannur, Thalassery, Kozhikode, Mangalore and Bangalore. Addresses, hours, seating, parking and direct order numbers.",
      },
      { property: "og:title", content: "Our 5 Outlets — Shawai Spot" },
      {
        property: "og:description",
        content: "Addresses, hours, seating, parking and direct order numbers for every Shawai Spot outlet.",
      },
    ],
  }),
  component: OutletsPage,
});

function OutletsPage() {
  return (
    <SiteLayout>
      {/* Hero */}
      <section className="py-20 px-6 text-center">
        <p className="section-eyebrow mb-4">Five Locations · One Taste</p>
        <h1 className="section-title">Our Outlets</h1>
        <div className="gold-divider" />
        <p className="text-muted-foreground max-w-2xl mx-auto">
          From our flagship in Kannur to our newest lounge in Bangalore — every Shawai Spot
          outlet brings the same authentic Arabian flavours, crafted with care.
        </p>

        {/* Quick jump pills */}
        <div className="mt-8 flex flex-wrap justify-center gap-2 max-w-3xl mx-auto">
          {OUTLETS.map((o) => (
            <a
              key={o.slug}
              href={`#${o.slug}`}
              className="text-xs uppercase tracking-[0.2em] border border-[color-mix(in_oklab,var(--gold)_35%,transparent)] rounded-full px-4 py-2 text-foreground/80 hover:text-gold hover:border-[var(--gold)] transition-all"
            >
              {o.city}
            </a>
          ))}
        </div>
      </section>

      {/* Outlet detail cards */}
      <section className="px-6 pb-20">
        <div className="max-w-6xl mx-auto space-y-10">
          {OUTLETS.map((o, idx) => (
            <article
              key={o.slug}
              id={o.slug}
              className="menu-card overflow-hidden grid lg:grid-cols-5 scroll-mt-28"
            >
              <div className="lg:col-span-2 h-72 lg:h-auto min-h-[280px]">
                <iframe
                  title={`${o.name} location`}
                  src={`https://www.google.com/maps?q=${encodeURIComponent(o.mapsQuery)}&output=embed`}
                  width="100%"
                  height="100%"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="w-full h-full grayscale-[0.3] contrast-90 border-0"
                />
              </div>

              <div className="lg:col-span-3 p-6 md:p-10">
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div>
                    <p className="text-xs uppercase tracking-[0.3em] text-gold mb-2">
                      Outlet 0{idx + 1}
                    </p>
                    <h2 className="font-serif text-2xl md:text-3xl text-foreground">{o.name}</h2>
                  </div>
                  {o.established && (
                    <span className="text-xs uppercase tracking-[0.2em] text-muted-foreground border border-border rounded-full px-3 py-1 inline-flex items-center gap-1.5">
                      <CalendarDays size={12} className="text-gold" /> Since {o.established}
                    </span>
                  )}
                </div>

                <div className="h-px w-16 bg-[var(--gradient-gold)] my-5" />

                {o.highlights && o.highlights.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-5">
                    {o.highlights.map((h) => (
                      <span
                        key={h}
                        className="inline-flex items-center gap-1.5 text-xs text-foreground/85 bg-[color-mix(in_oklab,var(--gold)_10%,transparent)] border border-[color-mix(in_oklab,var(--gold)_25%,transparent)] rounded-full px-3 py-1"
                      >
                        <Sparkles size={11} className="text-gold" /> {h}
                      </span>
                    ))}
                  </div>
                )}

                <div className="grid sm:grid-cols-2 gap-x-6 gap-y-3 text-sm">
                  <Detail icon={MapPin} label="Address" value={o.address} />
                  <Detail
                    icon={Phone}
                    label="Phone"
                    value={
                      <a
                        href={`tel:${o.phone.replace(/\s+/g, "")}`}
                        className="hover:text-gold transition"
                      >
                        {o.phone}
                      </a>
                    }
                  />
                  <Detail icon={Clock} label="Hours" value={o.hours} />
                  {o.manager && <Detail icon={User} label="Manager" value={o.manager} />}
                  {o.seating && <Detail icon={Armchair} label="Seating" value={o.seating} />}
                  {o.parking && <Detail icon={Car} label="Parking" value={o.parking} />}
                </div>

                <div className="mt-7 flex flex-wrap gap-3">
                  <a
                    href={`https://wa.me/${o.whatsapp}?text=${ORDER_MSG}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-whatsapp"
                  >
                    <MessageCircle size={16} /> Order on WhatsApp
                  </a>
                  <a
                    href={`tel:${o.phone.replace(/\s+/g, "")}`}
                    className="btn-call"
                  >
                    <Phone size={16} /> Call Outlet
                  </a>
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* CTA */}
        <div className="max-w-3xl mx-auto mt-16 text-center menu-card p-8">
          <p className="section-eyebrow mb-3">Coming Soon</p>
          <h3 className="font-serif text-2xl mb-2">More outlets on the way</h3>
          <p className="text-muted-foreground text-sm mb-5">
            We're expanding across South India. For franchise enquiries or general questions, reach out.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 text-gold hover:gap-3 transition-all uppercase tracking-[0.2em] text-xs"
          >
            Contact Head Office →
          </Link>
        </div>

        <p className="text-center text-xs text-muted-foreground italic mt-10">
          All prices are in INR. Pre-order items require advance booking.
        </p>
      </section>
    </SiteLayout>
  );
}

function Detail({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ size?: number; className?: string }>;
  label: string;
  value: React.ReactNode;
}) {
  return (
    <div className="flex items-start gap-3">
      <Icon size={15} className="text-gold mt-1 shrink-0" />
      <div>
        <p className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground mb-0.5">
          {label}
        </p>
        <p className="text-foreground/90">{value}</p>
      </div>
    </div>
  );
}
