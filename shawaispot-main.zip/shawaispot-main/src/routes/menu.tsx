import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-layout";
import { MenuSection } from "@/components/menu-section";

export const Route = createFileRoute("/menu")({
  head: () => ({
    meta: [
      { title: "Menu — Shawai Spot · Arabian Kitchen" },
      {
        name: "description",
        content:
          "Explore the Shawai Spot menu: shawarma, alfahm, madhooth, peri peri, sides and authentic Arabian add-ons.",
      },
      { property: "og:title", content: "Menu — Shawai Spot" },
      {
        property: "og:description",
        content: "Shawarma, alfahm, madhooth and more — authentic Arabian cuisine.",
      },
    ],
  }),
  component: MenuPage,
});

function MenuPage() {
  return (
    <SiteLayout>
      <section className="py-16 px-6">
        <div className="max-w-6xl mx-auto text-center mb-16">
          <p className="section-eyebrow mb-4">Our Kitchen</p>
          <h1 className="section-title">The Menu</h1>
          <div className="gold-divider" />
          <p className="max-w-xl mx-auto text-muted-foreground">
            Each dish is hand-prepared with traditional Arabian spices and slow-cooked
            techniques passed down through generations.
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <MenuSection
            title="Chicken & Beef"
            emoji="🍗"
            items={[
              { name: "Chicken Madhooth", description: "Tender chicken layered over spiced basmati.", popular: true },
              { name: "Beef Madhooth", description: "Slow-cooked beef with aromatic Arabian rice." },
            ]}
          />

          <MenuSection
            title="Mutton"
            emoji="🐐"
            items={[
              { name: "Mutton Madhooth", description: "Premium mutton on saffron-infused rice.", popular: true },
            ]}
          />

          <MenuSection
            title="Shawai"
            emoji="🍛"
            items={[
              { name: "Shawai with Kuboos", description: "Signature grilled shawai served with warm kuboos." },
              { name: "Shawai with Arabian Rice", description: "House shawai paired with fragrant rice." },
            ]}
          />

          <MenuSection
            title="Alfahm"
            emoji="🔥"
            items={[
              { name: "Alfahm with Kuboos", description: "Charcoal-grilled chicken with kuboos.", popular: true },
              { name: "Alfahm without Kuboos", description: "The classic, served on its own." },
              { name: "Alfahm with Rice", description: "Grilled alfahm over Arabian rice." },
              { name: "Plain Arabian Rice", description: "Aromatic basmati, lightly spiced." },
            ]}
          />

          <MenuSection
            title="Alfahm Peri Peri"
            emoji="🌶"
            items={[
              { name: "Peri Peri with Kuboos", description: "Fiery peri peri marinade with kuboos." },
              { name: "Peri Peri without Kuboos", description: "Bold heat, pure flavour." },
              { name: "Peri Peri with Rice", description: "Spicy peri peri on Arabian rice." },
            ]}
          />

          <MenuSection
            title="Sides"
            emoji="🍟"
            items={[{ name: "French Fries", description: "Crispy golden, lightly salted." }]}
          />

          <MenuSection
            title="Add-ons"
            emoji="✨"
            items={[
              { name: "Kuboos" },
              { name: "Porotta / Parota" },
              { name: "Rumali" },
              { name: "Mayonnaise" },
              { name: "Sulaimani" },
            ]}
          />
        </div>

        <p className="text-center text-xs text-muted-foreground italic mt-10">
          All prices are in INR. Pre-order items require advance booking.
        </p>
      </section>
    </SiteLayout>
  );
}
