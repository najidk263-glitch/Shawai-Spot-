export type Outlet = {
  slug: string;
  name: string;
  city: string;
  address: string;
  phone: string;
  whatsapp: string; // digits only
  hours: string;
  manager?: string;
  seating?: string;
  parking?: string;
  established?: string;
  highlights?: string[];
  mapsQuery: string;
};

// Add your outlets here. Duplicate the template below for each outlet.
// `slug` must be unique (used in URLs / anchors). `whatsapp` = digits only, no + or spaces.
export const OUTLETS: Outlet[] = [
  {
    slug: "koduvally",
    name: "Shawai Spot — Koduvally",
    city: "Koduvally",
    address: "Koduvally, Kozhikode, Kerala",
    phone: "+91 75105 00769",
    whatsapp: "917510500769",
    hours: "Daily · 11:00 AM – 11:30 PM",
    mapsQuery: "Shawai Spot Koduvally Kozhikode Kerala",
  },
  {
    slug: "omassery",
    name: "Shawai Spot — Omassery",
    city: "Omassery",
    address: "Omassery, Kozhikode, Kerala",
    phone: "+91 73700 46004",
    whatsapp: "917370046004",
    hours: "Daily · 11:00 AM – 11:30 PM",
    mapsQuery: "Shawai Spot Omassery Kozhikode Kerala",
  },
  {
    slug: "valanchery",
    name: "Shawai Spot — Valanchery",
    city: "Valanchery",
    address: "Valanchery, Malappuram, Kerala",
    phone: "+91 90484 00769",
    whatsapp: "919048400769",
    hours: "Daily · 11:00 AM – 11:30 PM",
    mapsQuery: "Shawai Spot Valanchery Malappuram Kerala",
  },
  {
    slug: "kunnamangalam",
    name: "Shawai Spot — Kunnamangalam",
    city: "Kunnamangalam",
    address: "Kunnamangalam, Kozhikode, Kerala",
    phone: "+91 97450 07697",
    whatsapp: "919745007697",
    hours: "Daily · 11:00 AM – 11:30 PM",
    mapsQuery: "Shawai Spot Kunnamangalam Kozhikode Kerala",
  },
  {
    slug: "kaythappoyil",
    name: "Shawai Spot — Kaythappoyil",
    city: "Kaythappoyil",
    address: "Kaythappoyil, Kozhikode, Kerala",
    phone: "+91 90440 08811",
    whatsapp: "919044008811",
    hours: "Daily · 11:00 AM – 11:30 PM",
    mapsQuery: "Shawai Spot Kaythappoyil Kozhikode Kerala",
  },
];

export const ORDER_MSG = encodeURIComponent("Hi Shawai Spot, I'd like to place an order.");
